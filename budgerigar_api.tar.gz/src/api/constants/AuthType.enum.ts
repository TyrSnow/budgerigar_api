enum AUTH_TYPE {
    USER = 0,
    ADMIN,
    ROOT
}
export default AUTH_TYPE;