/**
 * 系统所有的路由表信息
 * ?不确定是否真的需要这么一个东西?
 */
function U(uri) {
    return (obj) => {

    }
}
export const URI = {

}