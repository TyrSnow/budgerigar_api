class CaptchaCtrl {
    /**
     * 生成验证码
     * 返回url和id
     */
    static generate(req, res) {
        


    }
    /**
     * 更新验证码的验证状态
     */
    static check(req, res) {
        let { id, code } = req.body;


    }
}