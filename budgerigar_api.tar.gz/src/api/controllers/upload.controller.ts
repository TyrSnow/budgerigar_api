class UploadCtrl {
  
}

export default UploadCtrl;
