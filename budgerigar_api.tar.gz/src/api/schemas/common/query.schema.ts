const querySchema = {
    type: 'object',
    properties: {
        k: 'string',
        s: 'number',
        i: 'number'
    }
}

export { querySchema }